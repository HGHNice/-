create definer = hghnb@`%` trigger check_number
    before insert
    on notice
    for each row
begin
    if new.Room_number < 0 then
        set new.Room_number = 0;
    end if;
    if new.WEG_Charges < 0 then
        set new.WEG_Charges = 0;
    end if;
    if new.Total_property_management_fee < 0 then
        set new.Total_property_management_fee = 0;
    end if;
    if new.TV_fee < 0 then
        set new.TV_fee = 0;
    end if;
    if new.Heating_cost < 0 then
        set new.Heating_cost = 0;
    end if;
    if new.house_payment_information < 0 then
        set new.house_payment_information = 0;
    end if;
end;

